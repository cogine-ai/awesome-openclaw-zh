# 让龙虾当3D设计师：做一座微缩工作台

教程：`usecases/creative/lobster-3d-workbench.md`。

材料目录包含输入文件、运行脚本和作品。按目录内 START-HERE.md 修改输入并重新生成。

[在线教程](https://www.opcboost.com/usecases/creative/lobster-3d-workbench/) · [案例仓库](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
