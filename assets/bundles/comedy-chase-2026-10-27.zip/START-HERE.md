# comedy-chase

解压后从本目录阅读 `usecases/creative/comedy-chase-action-continuity.md`。
输入、实际产物、复现脚本和上游许可在 `assets/examples/comedy-chase/`。
先阅读案例的前置条件和验证范围，再执行命令。此包不含模型凭证或已生成视频。

文字预览重建：`python3 scripts/generate-showcase-previews.py --pack comedy-chase`。

[完整教程与更新](https://www.opcboost.com/usecases/creative/comedy-chase-action-continuity/) · [案例仓库与共建](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
