# comedy-chase

解压后从本目录阅读 `usecases/creative/comedy-chase-action-continuity.md`。
输入、实际产物、复现脚本和上游许可在 `assets/examples/comedy-chase/`。
先按教程准备工具，再替换输入、运行脚本，制作自己的版本。

文字预览重建：`python3 scripts/generate-showcase-previews.py --pack comedy-chase`。

[完整教程与更新](https://www.opcboost.com/usecases/creative/comedy-chase-action-continuity/) · [案例仓库与共建](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
