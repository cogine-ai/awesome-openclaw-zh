# 三期播客变成观点分歧地图

教程：`usecases/content/podcast-disagreement-map.md`。

材料目录包含输入文件、运行脚本和作品。按目录内 START-HERE.md 修改输入并重新生成。

[在线教程](https://www.opcboost.com/usecases/content/podcast-disagreement-map/) · [案例仓库](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
