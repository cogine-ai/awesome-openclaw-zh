# github-cards

解压后从本目录阅读 `usecases/creative/github-handdrawn-project-cards.md`。
输入、实际产物、复现脚本和上游许可在 `assets/examples/github-cards/`。
先阅读案例的前置条件和验证范围，再执行命令。此包不含模型凭证或已生成视频。

[完整教程与更新](https://www.opcboost.com/usecases/creative/github-handdrawn-project-cards/) · [案例仓库与共建](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
