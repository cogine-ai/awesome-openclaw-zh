# github-cards

解压后从本目录阅读 `usecases/creative/github-handdrawn-project-cards.md`。
输入、示例产物与复现脚本在 `assets/examples/github-cards/`。
先按教程准备工具、运行原始示例，再替换输入，使用对应的运行命令制作自己的版本。

[完整教程与更新](https://www.opcboost.com/usecases/creative/github-handdrawn-project-cards/) · [案例仓库与共建](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
