# bilibili-audience-brief

解压后从本目录阅读 `usecases/social/bilibili-audience-to-topic-brief.md`。
输入、示例产物与复现脚本在 `assets/examples/bilibili-audience-brief/`。
先按教程准备工具、运行原始示例，再替换输入，使用对应的运行命令制作自己的版本。

[完整教程与更新](https://www.opcboost.com/usecases/social/bilibili-audience-to-topic-brief/) · [案例仓库与共建](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
