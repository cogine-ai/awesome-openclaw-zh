# interactive-desktop-coach

解压后从本目录阅读 `usecases/tools/interactive-desktop-coach.md`。
输入、实际产物、复现脚本和上游许可在 `assets/examples/interactive-desktop-coach/`。
先按教程准备工具，再替换输入、运行脚本，制作自己的版本。

[完整教程与更新](https://www.opcboost.com/usecases/tools/interactive-desktop-coach/) · [案例仓库与共建](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
