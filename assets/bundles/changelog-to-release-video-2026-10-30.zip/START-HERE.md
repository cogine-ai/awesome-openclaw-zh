# 更新日志变成30秒发布片：保留可修改工程

教程：`usecases/creative/changelog-to-release-video.md`。

材料目录包含输入文件、运行脚本和作品。按目录内 START-HERE.md 修改输入并重新生成。

[在线教程](https://www.opcboost.com/usecases/creative/changelog-to-release-video/) · [案例仓库](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
