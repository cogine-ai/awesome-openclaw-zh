# 让龙虾做能打印的桌牌、贴纸与折页

教程：`usecases/creative/printable-event-kit.md`。

材料目录包含输入文件、运行脚本和作品。按目录内 START-HERE.md 修改输入并重新生成。

[在线教程](https://www.opcboost.com/usecases/creative/printable-event-kit/) · [案例仓库](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
