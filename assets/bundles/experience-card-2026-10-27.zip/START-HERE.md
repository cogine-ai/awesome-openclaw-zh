# experience-card

解压后从本目录阅读 `usecases/productivity/experience-interview-record-card.md`。
输入、实际产物、复现脚本和上游许可在 `assets/examples/experience-card/`。
先阅读案例的前置条件和验证范围，再执行命令。此包不含模型凭证或已生成视频。

文字预览重建：`python3 scripts/generate-showcase-previews.py --pack experience-card`。

[完整教程与更新](https://www.opcboost.com/usecases/productivity/experience-interview-record-card/) · [案例仓库与共建](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
