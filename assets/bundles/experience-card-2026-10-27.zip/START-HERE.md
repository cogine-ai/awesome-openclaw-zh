# experience-card

解压后从本目录阅读 `usecases/productivity/experience-interview-record-card.md`。
输入、示例产物与复现脚本在 `assets/examples/experience-card/`。
先按教程准备工具、运行原始示例，再替换输入，使用对应的运行命令制作自己的版本。

文字预览重建：`python3 scripts/generate-showcase-previews.py --pack experience-card`。

[完整教程与更新](https://www.opcboost.com/usecases/productivity/experience-interview-record-card/) · [案例仓库与共建](https://github.com/cogine-ai/awesome-openclaw-zh) · [Cogine](https://www.cogine.ai/)
